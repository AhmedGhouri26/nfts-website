(function () {
    'use strict';

    $("#sticker").sticky({topSpacing:24});

    $('#onePageNav').onePageNav({
        scrollSpeed: 300
    });

})();