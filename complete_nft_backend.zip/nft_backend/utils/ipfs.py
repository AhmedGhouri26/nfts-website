def dummy_upload_to_ipfs(filepath):
    filename = filepath.split('/')[-1]
    return f"ipfs://dummy_hash_for_{filename}"