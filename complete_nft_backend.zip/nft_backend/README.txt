# NFT Backend (Complete)

## Features:
- Submit wallet & email
- Upload NFT file (image/video)
- Upload to IPFS (dummy)
- Generate metadata & upload to IPFS
- Mint NFT (dummy XRPL hash)
- Save all data in SQLite DB
- View all NFTs by wallet

## Setup:
1. pip install -r requirements.txt
2. python app.py
3. Use Postman or frontend to test endpoints

Edit 'utils/ipfs.py' for real IPFS integration.