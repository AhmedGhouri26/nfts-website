from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import os
import sqlite3
import json
from datetime import datetime
from werkzeug.utils import secure_filename
from utils.ipfs import dummy_upload_to_ipfs

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

DB_PATH = 'nft_data.db'

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS nft_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                wallet_address TEXT,
                email TEXT,
                filename TEXT,
                ipfs_file_url TEXT,
                ipfs_metadata_url TEXT,
                mint_tx_hash TEXT,
                created_at TEXT
            )
        ''')
init_db()

@app.route('/submit-wallet', methods=['POST'])
def submit_wallet():
    data = request.json
    wallet = data.get('wallet')
    email = data.get('email')
    if not wallet:
        return jsonify({'error': 'Wallet address required'}), 400
    return jsonify({'message': 'Wallet submitted successfully', 'wallet': wallet})

@app.route('/upload-nft-file', methods=['POST'])
def upload_nft_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    file = request.files['file']
    filename = secure_filename(file.filename)
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(path)
    return jsonify({'message': 'File uploaded', 'filename': filename, 'path': path})

@app.route('/upload-to-ipfs', methods=['POST'])
def upload_to_ipfs():
    data = request.json
    filepath = data.get('filepath')
    if not filepath or not os.path.exists(filepath):
        return jsonify({'error': 'File not found'}), 400
    ipfs_url = dummy_upload_to_ipfs(filepath)
    return jsonify({'ipfs_url': ipfs_url})

@app.route('/generate-metadata', methods=['POST'])
def generate_metadata():
    data = request.json
    name = data.get('name')
    description = data.get('description')
    image_ipfs = data.get('image_ipfs')
    metadata = {
        "name": name,
        "description": description,
        "image": image_ipfs
    }
    metadata_path = os.path.join(app.config['UPLOAD_FOLDER'], 'metadata.json')
    with open(metadata_path, 'w') as f:
        json.dump(metadata, f)
    metadata_ipfs = dummy_upload_to_ipfs(metadata_path)
    return jsonify({'metadata_ipfs': metadata_ipfs})

@app.route('/mint-nft', methods=['POST'])
def mint_nft():
    data = request.json
    wallet = data.get('wallet')
    email = data.get('email')
    filename = data.get('filename')
    ipfs_file_url = data.get('ipfs_file_url')
    ipfs_metadata_url = data.get('ipfs_metadata_url')
    mint_tx_hash = 'dummy_xrpl_tx_hash_12345'

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            INSERT INTO nft_records (wallet_address, email, filename, ipfs_file_url, ipfs_metadata_url, mint_tx_hash, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (wallet, email, filename, ipfs_file_url, ipfs_metadata_url, mint_tx_hash, datetime.utcnow().isoformat()))
        conn.commit()

    return jsonify({'message': 'NFT minted successfully', 'tx_hash': mint_tx_hash})

@app.route('/get-nfts/<wallet>', methods=['GET'])
def get_nfts(wallet):
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.execute('SELECT * FROM nft_records WHERE wallet_address = ?', (wallet,))
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        data = [dict(zip(columns, row)) for row in rows]
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)